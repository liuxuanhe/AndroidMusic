package com.seven.music

import android.content.Intent
import kotlinx.android.synthetic.main.activity_splash.*
import android.os.CountDownTimer
import com.bumptech.glide.Glide

class SplashActivity : BaseActivity() {

    val AD_URL ="https://music.yiroote.com/images/ads/ad720.jpg"

    override fun getLayoutId(): Int {
        return R.layout.activity_splash
    }

    override fun initView() {
        btn_escape.isEnabled=false
        btn_escape.setOnClickListener { escapeSplash() }
        Glide.with(this).load(AD_URL).into(iv_ad);
    }

    private fun escapeSplash() {
        val intent = Intent(this, MainActivity::class.java)
        startActivity(intent)
    }

    override fun initEvent() {
        val countDownTimer = object : CountDownTimer(5000, 1000) {
            override fun onTick(l: Long) {
               val i= l/1000
                btn_escape.setText(i.toString())
            }
            override fun onFinish() {
                btn_escape.isEnabled=true
            }
        }.start()

    }
}
