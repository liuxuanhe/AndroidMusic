package com.seven.music

class MainActivity : BaseActivity() {
    override fun initEvent() {
    }


    override fun getLayoutId(): Int {
        return R.layout.activity_main
    }

    override fun initView() {
    }
}
